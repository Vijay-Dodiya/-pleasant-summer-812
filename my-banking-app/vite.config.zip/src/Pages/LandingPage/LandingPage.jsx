import { Box, Grid, Image, Flex, Text, Link, GridItem } from "@chakra-ui/react";

const LandingPage = () => {
  return (
    // <Grid templateColumns="1fr 1fr" gap={8} maxW="1200px" mx="auto" p={4}>
    //   <Box>
    //     <Image
    //       src="/path/to/your/image.jpg"
    //       alt="Background Image"
    //       objectFit="cover"
    //       w="100%"
    //       h="100vh"
    //     />
    //     <Box
    //       pos="absolute"
    //       top="50%"
    //       left="50%"
    //       transform="translate(-50%, -50%)"
    //       textAlign="center"
    //     >
    //       <Text fontSize="3xl" color="white" fontWeight="bold">
    //         Write on the Image
    //       </Text>
    //     </Box>
    //   </Box>

    //   <Flex direction="column" justify="center">
    //     <Box mb={4}>
    //       <Link href="/loans" color="blue.500" fontSize="xl">
    //         Loans
    //       </Link>
    //     </Box>
    //     <Box mb={4}>
    //       <Link href="/account" color="blue.500" fontSize="xl">
    //         Account
    //       </Link>
    //     </Box>
    //     <Box mb={4}>
    //       <Link href="/transfer" color="blue.500" fontSize="xl">
    //         Transfer
    //       </Link>
    //     </Box>
    //     <Box mb={4}>
    //       <Link href="/more" color="blue.500" fontSize="xl">
    //         More
    //       </Link>
    //     </Box>
    //   </Flex>
    // </Grid>
    <Grid
      h="500px"
      templateRows="repeat(2, 1fr)"
      templateColumns="repeat(4, 1fr)"
      gap={4}
      mt={"2%"}
    >
      <GridItem rowSpan={2} colSpan={2} bg="tomato"></GridItem>
      <GridItem colSpan={1} bg="papayawhip">
        <Text>Account</Text>
      </GridItem>
      <GridItem colSpan={1} bg="papayawhip">
        <Text>Cards</Text>
      </GridItem>
      <GridItem colSpan={1} bg="papayawhip">
        <Text>Loans</Text>
      </GridItem>
      <GridItem colSpan={1} bg="tomato">
        <Text>Offers</Text>
      </GridItem>
    </Grid>
  );
};

export default LandingPage;
