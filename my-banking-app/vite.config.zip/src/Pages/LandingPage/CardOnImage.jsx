import React from "react";
import { Box, Image, Center, VStack, Button } from "@chakra-ui/react";
import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  Heading,
  Stack,
  Text,
  Divider,
  ButtonGroup,
} from "@chakra-ui/react";
const CardOnImage = () => {
  return (
    <div>
      <Box width="100%" position="relative">
        <Image
          src="https://img.freepik.com/premium-vector/bank-office-interior-with-clients-getting-financial-banking-services-consultation-with-finance-specialists-credit-payment-advisors-cartoon-flat-vector-illustration_341509-2421.jpg"
          alt="Image"
          width="100%"
        />
        <Center
          position="absolute"
          top="30%"
          left="80%"
          transform="translate(-5%, 10%)"
        >
          <VStack spacing="10">
            <Card maxW="sm" bg={"red"}>
              <CardBody>
                <Stack mt="6" spacing="3">
                  <Heading size="xl">Change the Way You Bank</Heading>
                  <Text>
                    Take your next step with PNC Virtual Wallet - checking,
                    savings and financial tools designed to go wherever you do.
                  </Text>
                </Stack>
              </CardBody>
              <Button
                variant="solid"
                colorScheme="blue"
                width={"70%"}
                left="10%"
              >
                Learn More and Explore
              </Button>
              <CardFooter>
                <ButtonGroup spacing="2"></ButtonGroup>
              </CardFooter>
            </Card>
          </VStack>
        </Center>
      </Box>
    </div>
  );
};

export default CardOnImage;
