import React from "react";
import Navbar from "./../Components/Navbar";

const Products = () => {
  return (
    <div>
      <h1>Products</h1>
      <Navbar />
    </div>
  );
};

export default Products;
