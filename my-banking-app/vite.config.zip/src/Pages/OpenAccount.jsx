import React from "react";

const OpenAccount = () => {
  return (
    <div>
      <h1>OpenAccount</h1>
    </div>
  );
};

export default OpenAccount;
