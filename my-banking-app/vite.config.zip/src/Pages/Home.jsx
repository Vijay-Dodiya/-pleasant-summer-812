import React from "react";
import LandingPage from "./LandingPage/LandingPage";
import Insight from "./LandingPage/Insight";
import CardOnImage from "./LandingPage/CardOnImage";

const Home = () => {
  return (
    <div>
      <CardOnImage />
      <LandingPage />
      <Insight />
    </div>
  );
};

export default Home;
