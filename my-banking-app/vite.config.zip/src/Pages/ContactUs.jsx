import React from "react";
import { Box, Heading, Text, Button, Input, Textarea } from "@chakra-ui/react";

const ContactUs = () => {
  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
  };

  return (
    <div>
      <Box maxW="600px" mx="auto" p={4}>
        <Heading as="h1" mb={4}>
          Contact Us
        </Heading>
        <Text mb={4}>
          Please fill out the form below to get in touch with us.
        </Text>

        <Box as="form" onSubmit={handleSubmit}>
          <Box mb={4}>
            <Input type="text" placeholder="Your Name" />
          </Box>
          <Box mb={4}>
            <Input type="email" placeholder="Your Email" />
          </Box>
          <Box mb={4}>
            <Textarea placeholder="Message" rows={6} />
          </Box>
          <Button colorScheme="blue" type="submit">
            Submit
          </Button>
        </Box>
      </Box>
    </div>
  );
};

export default ContactUs;
